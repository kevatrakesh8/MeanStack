import { Injectable, ElementRef } from '@angular/core';


@Injectable()
export class WrapperService {
  public wrapperElementRef!: ElementRef;
}
