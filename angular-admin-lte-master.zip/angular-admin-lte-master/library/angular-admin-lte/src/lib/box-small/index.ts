export * from './box-small.module';
